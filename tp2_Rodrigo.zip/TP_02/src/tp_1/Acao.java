package tp_1;
/**
 * 
 * @author rodrigo
 * A classe Acao contem as possiveis acoes dos lutadores como ataque, soco, chute, poder, defesa
 *
 */
public class Acao {

	public String ataque;
	public String soco;
	public String chute;
	public String poder;
	public String defesa;
	
	public Acao(){
	}
/*
	public int getAtaque() {
		return ataque;
	}

	public void setAtaque(int ataque) {
		this.ataque = ataque;
	}

	public int getSoco() {
		return soco;
	}

	public void setSoco(int soco) {
		this.soco = soco;
	}

	public int getChute() {
		return chute;
	}

	public void setChute(int chute) {
		this.chute = chute;
	}

	public int getPoder() {
		return poder;
	}

	public void setPoder(int poder) {
		this.poder = poder;
	}

	public int getDefesa() {
		return defesa;
	}

	public void setDefesa(int defesa) {
		this.defesa = defesa;
	}*/
	
	
	
}
